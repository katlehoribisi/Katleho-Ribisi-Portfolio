# #Q1
# numOfEggs = int(input("How many eggs did you order?: "))
# dozensCalc = numOfEggs / 12

# dozens = int(dozensCalc)

# looseEggs = numOfEggs - (dozens * 12)

# totalCost = (dozens * 3.25) + looseEggs * 0.45

# print(f"You ordered {numOfEggs} eggs. That's {dozens} dozen at R3.25 per dozen and {looseEggs} at 45c each for a total of R81.25.")


# #Question 2

# def findPrimeMultiples(number):

#     primeList = []
#     div = 2


#     while div <= number:
#         if number % div == 0:
#             primeList.append(div)
#             number = number / div
#         else:
#             div += 1

#     return primeList

        
# factorNum = int(input("Enter number you want to factorize: "))

# print(findPrimeMultiples(factorNum))
        


#Question 3
import random

def startGame():

    print("Lets play a multiplication game!")

    list = [1,2,3,4,5,6,7,8,9,10]
    ranNum = random.choice((list))
    ranNum1 = random.choice((list))

    list2 = [1,2,3,4,5,6,7,8,9,10]
    ranNum2 = random.choice((list2))
    ranNum3 = random.choice((list2))

    score = 0

    answer1 = int(input(f"What is the product of {ranNum} and {ranNum1}?: "))
    if answer1 == ranNum * ranNum1:
        print("Correct!")
        score += 1
    else:
        print("Incorrect")
    

    answer2 = int(input(f"What is {ranNum2} x {ranNum3}?: "))
    if answer2 == ranNum2 * ranNum3:
        print("Correct!")
        score += 1
    else:
        print("Incorrect")
    
    print(f"Your score is {score}!")

startGame()

#play game agian
play_again = True

while play_again == True:
    replay = input("Do you want to play again? (y/n) ")
    if replay == "y" or replay == "yes" or replay == "Yes":
        startGame()
    else:
        print("Thanks for playing.")
        play_again = False

