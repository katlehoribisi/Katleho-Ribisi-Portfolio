class CtuStock:
    def __init__(
            #Shopname Attributes for 4 shops
            self = "default", 
            shopName = "default", 
            #Shoplocation Attributes for 4 shops
            shopLocation = "default", 
            #Customers Attributes for 4 shops
            customers = 0, 
            #Sales Attributes for 4 shops
            sales = 0, 
            #Return Attributes for 4 shops
            returns = 0,
            hardrives = 1000,
            updatedHardStock = 0,
            counter = "off/on",
            counter1 = "off/on",
            
            itemNumber = 0,
            quanToSell = 0,
            ):

        self.shopName = shopName
        self.shopLocation = shopLocation
        self.customers = customers
        self.sales = sales
        self.returns = returns
        self.hardrives = hardrives
        self.updatedHardStock = updatedHardStock
        self.counter = counter
        self.counter1 = counter1
        self.itemNumber = itemNumber
        self.quanToSell = quanToSell
        
    #Code for the main menu
    while True:
        def mainMenu(self):
            self.updatedHardStock = self.hardrives
            print("Welcome to CTU Technologies")
            print("")
            print("1. Shop Management")
            print("2. Sales")
            print("3. Returns")
            print("4. Stock")
            print("99. Exit")
            print("")
            
            mainMenuSelect = input("Select an option or 99 to exit: ")
            if mainMenuSelect == "":
                print("Please enter a correct number!")
                CtuStock.mainMenu(self)

                    
            if mainMenuSelect == "1":
                print("")
                
                print("Shop Management")
                print("1. Change shop Name")
                print("2. Change shop location")
                print("3. Display current shops")
                print("4. Display all shops information")
                print("0. Back")
                print("")

                nestSelect = input("Select an option: ")
                if nestSelect == "0":
                    CtuStock.mainMenu(self)

            # --- --- --- --- --- --- --- --- --- --- 
                            #Option 1 
                # Functions to change the shopnames
                # Functions to change shoplocations
                # Functions to design a buy function
            # --- --- --- --- --- --- --- --- --- --- 
                def change():
                    self.shopName = input("Type the new Shop name: ")

                    areYouSure = input("Are you sure you want to confirm this answer?: (y/n)")
                    if areYouSure == "y" or areYouSure == "yes":
                        print(f"Shop name was succsessfully changed to: {self.shopName}")
                    else:
                        self.shopName = "Default"

                def change1():
                    self.shopName1 = input("Type the new Shop name: ")

                    areYouSure = input("Are you sure you want to confirm this answer? (y/n): ")
                    if areYouSure == "y" or areYouSure == "yes":
                        print(f"Shop name was succsessfully changed to: {self.shopName1}")
                    else:
                        self.shopName1 = "Default"

                def change2():
                    self.shopName2 = input("Type the new Shop name: ")

                    areYouSure = input("Are you sure you want to confirm this answer? (y/n): ")
                    if areYouSure == "y" or areYouSure == "yes":
                        print(f"Shop name was succsessfully changed to: {self.shopName2}")
                    else:
                        self.shopName2 = "Default"

                def change3():
                    self.shopName3 = input("Type the new Shop name: ")

                    areYouSure = input("Are you sure you want to confirm this answer? (y/n): ")
                    if areYouSure == "y" or areYouSure == "yes":
                        print(f"Shop name was succsessfully changed to: {self.shopName3}")
                    else:
                        self.shopName3 = "Default"

                #Functions to change the shop locations
                def changeLocation():
                    self.shopLocation = input("Enter a location: ")
                    areYouSure = input("Are you sure you want to confirm this answer? (y/n): ")
                    if areYouSure == "y" or areYouSure == "yes":
                        print(f"Shop location successfully changed to: {self.shopLocation}")
                    else:
                        self.shopLocation = "Default"

                def changeLocation1():
                    self.shopLocation1 = input("Enter a location: ")
                    areYouSure = input("Are you sure you want to confirm this answer? (y/n): ")
                    if areYouSure == "y" or areYouSure == "yes":
                        print(f"Shop location successfully changed to: {self.shopLocation1}")
                    else:
                        self.shopLocation1 = "Default"

                def changeLocation2():
                    self.shopLocation2 = input("Enter a location: ")
                    areYouSure = input("Are you sure you want to confirm this answer? (y/n): ")
                    if areYouSure == "y" or areYouSure == "yes":
                        print(f"Shop location successfully changed to: {self.shopLocation2}")
                    else:
                        self.shopLocation2 = "Default"

                def changeLocation3():
                    self.shopLocation3 = input("Enter a location: ")
                    areYouSure = input("Are you sure you want to confirm this answer? (y/n): ")
                    if areYouSure == "y" or areYouSure == "yes":
                        print(f"Shop location successfully changed to: {self.shopLocation3}")
                    else:
                        self.shopLocation3 = "Default"

                #--- --- --- --- --- --- --- --- --- --- 
                #--- --- --- --- --- --- --- --- --- --- 


                while True:
                    #Change shop name code
                    if nestSelect == "1":
                        print("Change shop name")
                        print("")
                        print("Select Shop")
                        print("1.",self.shopName)
                        print("2.",self.shopName1)
                        print("3.",self.shopName2)
                        print("4.",self.shopName3)
                        print("0. Back")
                        nestSelect2 = input("Select an option: ")
                        if nestSelect2 == "1":
                            change()
                        elif nestSelect2 == "2":
                            change1()
                        elif nestSelect2 == "3":
                            change2()
                        elif nestSelect2 == "4":
                            change3()
                        elif nestSelect2 == "0":
                            CtuStock.mainMenu(self)

                    #Change shop location code
                    if nestSelect == "2":
                        print("Change shop Location")
                        print("")
                        print("Select Location")
                        print(f"1. {self.shopName} {self.shopLocation}")
                        print(f"2. {self.shopName1} {self.shopLocation1}")
                        print(f"3. {self.shopName2} {self.shopLocation2}")
                        print(f"4. {self.shopName3} {self.shopLocation3}")
                        print("0. Back") 
                        nestSelect2 = input("Select an option: ")
                        if nestSelect2 == "1":
                            changeLocation()
                        elif nestSelect2 == "2":
                            changeLocation1()
                        elif nestSelect2 == "3":
                            changeLocation2()
                        elif nestSelect2 == "4":
                            changeLocation3()
                        elif nestSelect2 == "0":
                            print("Works")
                            CtuStock.mainMenu(self)

                    if nestSelect == "3":
                        def showShops():
                            print("Current Shops")
                            print("")                
                            print(f"Shop 1 is: {self.shopName}, {self.shopLocation}")
                            print(f"Shop 2 is: {self.shopName1}, {self.shopLocation1}")
                            print(f"Shop 3 is: {self.shopName2}, {self.shopLocation2}")
                            print(f"Shop 4 is: {self.shopName3}, {self.shopLocation3}")
                            print("")  
                        showShops() 
                        CtuStock.mainMenu(self)
                    if nestSelect == "4":
                        def showAll():
                            #Shop 1
                            print("----------------")
                            print("")
                            print(f"Shop Name: {self.shopName}")
                            print(f"Shop Location: {self.shopLocation}")
                            print(f"Number of Customers: {self.customers}")
                            print(f"Current Sales: {self.sales}")
                            print("")
                            print("----------------")
                            print("")

                            #Shop 2
                            print("----------------")
                            print("")
                            print(f"Shop Name: {self.shopName1}")
                            print(f"Shop Location: {self.shopLocation1}")
                            print(f"Number of Customers: {self.customers1}")
                            print(f"Current Sales: {self.sales1}")
                            print("")
                            print("----------------")
                            print("")

                            #Shop 3
                            print("----------------")
                            print("")
                            print(f"Shop Name: {self.shopName2}")
                            print(f"Shop Location: {self.shopLocation2}")
                            print(f"Number of Customers: {self.customers2}")
                            print(f"Current Sales: {self.sales2}")
                            print("")
                            print("----------------")
                            print("")

                            #Shop 4
                            print("----------------")
                            print("")
                            print(f"Shop Name: {self.shopName3}")
                            print(f"Shop Location: {self.shopLocation3}")
                            print(f"Number of Customers: {self.customers3}")
                            print(f"Current Sales: {self.sales3}")
                            print("")
                            print("----------------")
                            print("")
                        showAll()
                    
                        CtuStock.mainMenu(self)
                        
            # --- --- --- --- --- --- --- --- --- ---
            # Code for SALES 
            # --- --- --- --- --- --- --- --- --- --- 
            if mainMenuSelect == "2":

                # --- --- --- --- --- --- --- --- --- --- 
                                #Option 2 (Sales)
                # Functions to repeat code without the input
                # --- --- --- --- --- --- --- --- --- --- 
                def showSalesSoFar():
                    print("")
                    print("Current Sales Information: ")
                    print("=== === === ")
                    print(f"Hardrives stock: {self.updatedHardStock}") 
                    print(f"Quantity sold for Shop 1: {self.quanToSell},        Item Number: {self.itemNumber}")
                    print("=== === === ")
                
                def availableItems():
                    prev = input("Do you want to sell again?: ")
                    if prev == "y":
                        self.counter = "off"
                        pass
                    elif prev == "n":
                        showSalesSoFar()
                        CtuStock.mainMenu(self)

                def itemNumber():
                    itemSell = int(input(f"2. Enter the item number to sell: "))
                    if itemSell == 0:
                        self.counter = "off"
                        CtuStock.mainMenu(self)
                    else:
                        self.itemNumber = itemSell
                def itemNumber1():
                    itemSell = int(input(f"2. Enter the item number to sell: "))
                    if itemSell == 0:
                        self.counter = "off"
                        CtuStock.mainMenu(self)
                    else:
                        self.itemNumber1 = itemSell
                def itemNumber2():
                    itemSell = int(input(f"2. Enter the item number to sell: "))
                    if itemSell == 0:
                        self.counter = "off"
                        CtuStock.mainMenu(self)
                    else:
                        self.itemNumber2 = itemSell
                def itemNumber3():
                    itemSell = int(input(f"2. Enter the item number to sell: "))
                    if itemSell == 0:
                        self.counter = "off"
                        CtuStock.mainMenu(self)
                    else:
                        self.itemNumber3 = itemSell

                def quanToSell():
                    quanToSell = int(input(f"3. Enter the quantity to sell: "))
                    self.quanToSell += quanToSell

                def quanToSell1():
                    quanToSell = int(input(f"3. Enter the quantity to sell: "))
                    self.quanToSell1 += quanToSell

                def quanToSell2():
                    quanToSell = int(input(f"3. Enter the quantity to sell: "))
                    self.quanToSell2 += quanToSell

                def quanToSell3():
                    quanToSell = int(input(f"3. Enter the quantity to sell: "))
                    self.quanToSell3 += quanToSell
                    
                    if quanToSell > 1000:
                        print("==============================")
                        print("Not enough in stock, sorry :(")
                        print("==============================")
                        self.counter = "off"
                        CtuStock.mainMenu(self)

                def back():
                    print(f"Item {self.itemNumber} sold successfully!")
                    print("")
                    back = input("Do you want to go back to main menu? (y/n): ")
                    if back == "y" or back == "Y" or back == "Yes" or back == "yes":
                        CtuStock.mainMenu(self)
                    elif back == "n" or back == "no":
                        showSales()
                        

                # --- --- --- --- --- --- --- --- --- ---
                # --- --- --- --- --- --- --- --- --- ---
                while True:
                    if self.counter == "on":
                        availableItems()
                    else:
                        def showSales():
                            self.counter = "on"
                            print("=== Sales ===")
                            print("Available items: ")
                            print("back: (0) ")
                            print(f"1. Hardrives: {self.updatedHardStock}")

                            while True:
                                sellFrom = int(input(f"4. Enter the shop number to sell from: "))
                                myRange = range(1,5)

                                if sellFrom == 1:
                                    itemNumber()
                                    quanToSell()
                                    self.sales = self.quanToSell #Shop 1
                                    back()

                                if sellFrom == 2:
                                    itemNumber1()
                                    quanToSell1()
                                    self.sales1 = self.quanToSell1 #Shop 2
                                    back()
                                
                                if sellFrom == 3:
                                    itemNumber2()
                                    quanToSell2()
                                    self.sales2 = self.quanToSell2 #Shop 3
                                    back()

                                if sellFrom == 4:
                                    itemNumber3()
                                    quanToSell3()
                                    self.sales3 = self.quanToSell3 #Shop 4
                                    back()
                                
                                if sellFrom in myRange:
                                    pass
                                else:
                                    print("Shop doesn't exist")

                        showSales()

            # --- --- --- --- --- --- --- --- --- ---
            # Code for RETURNS
            # --- --- --- --- --- --- --- --- --- --- 
            if mainMenuSelect == "3":
                while True:
                    # --- --- --- --- --- --- --- --- --- --- 
                                    #Option 3
                    # Functions to Return an item back to the shop
                    # --- --- --- --- --- --- --- --- --- ---

                    
                    def showReturnsInformation():
                        print("")
                        print("Current Returns Information: ")
                        print("=== === === ")
                        print(f"Hardrives stock: {self.updatedHardStock}") 
                        print(f"Quantity returned for Shop 1: {self.quanToSell},        Item Number: {self.itemNumber}")
                        print(f"Quantity returned for Shop 2: {self.quanToSell1},       Item Number: {self.itemNumber1}")
                        print(f"Quantity returned for Shop 3: {self.quanToSell2},       Item Number: {self.itemNumber2}")
                        print(f"Quantity returned for Shop 4: {self.quanToSell3},       Item Number: {self.itemNumber3}")
                        print("=== === === ")

                    def itemReturn():
                        confirm = int(input(f"Enter the item number to return: "))
                        if confirm == self.itemNumber:
                            pass
                        else:
                            print("Wrong item number.")

                    def itemReturn1():
                        input(f"Enter the item number to return: ")
                    def itemReturn2():
                        input(f"Enter the item number to return: ")
                    def itemReturn3():
                        input(f"Enter the item number to return: ")

                    def shopToReturn():
                        return1 = int(input(f"How much do you want to return?: "))
                        if return1 > self.updatedHardStock:
                            print("")
                            print("Couldn't return, sorry.")
                            print("")
                            CtuStock.mainMenu(self)
                        else:
                            self.sales -= return1
                            self.hardrives += return1
                    def shopToReturn1():
                        return2 = int(input(f"How much do you want to return?: "))
                        if return2 > self.updatedHardStock:
                            print("")
                            print("Couldn't return, sorry.")
                            print("")
                            CtuStock.mainMenu(self)
                        else:
                            self.sales -= return2
                            self.hardrives += return2
                    def shopToReturn2():
                        return3 = int(input(f"How much do you want to return?: "))
                        if return3 > self.updatedHardStock:
                            print("")
                            print("Couldn't return, sorry.")
                            print("")
                            CtuStock.mainMenu(self)
                        else:
                            self.sales -= return3
                            self.hardrives += return3
                    def shopToReturn3():
                        return4 = int(input(f"How much do you want to return?: "))
                        if return4 > self.updatedHardStock:
                            print("")
                            print("Couldn't return, sorry.")
                            print("")
                            CtuStock.mainMenu(self)
                        else:
                            self.sales -= return4
                            self.hardrives += return4


                    # --- --- --- --- --- --- --- --- --- ---

                    print("")
                    print("=== Returns === ")
                    print("Available Items: ")
                    print(f"1. Hardrives: {self.updatedHardStock}")
                    while True:
                        returnTo = int(input(f"Enter the shop number to return to: "))
                        
                        myRange = range(1,5)
                        if returnTo == 1:
                            itemReturn()
                            shopToReturn()
                        if returnTo == 2:
                            itemReturn1()
                            shopToReturn1()
                        if returnTo == 3:
                            itemReturn2()
                            shopToReturn2()
                        if returnTo == 4:
                            itemReturn3()
                            shopToReturn3()

                        if returnTo in myRange:
                            back = input("Are you sure with these values? (y/n): ")
                            print(f"Item {self.itemNumber} returned successfully!")
                            print("")
                            if back == "y" or back == "Y" or back == "Yes" or back == "yes":
                                CtuStock.mainMenu(self)
                            elif back == "n" or back == "no":
                                showReturnsInformation()
                        else:
                            print("Shop doesn't exist.")

                        print(f"Enter the quantity to return: {self.returns2}")
                        print(f"Enter the shop number to return to: {self.returns3}")
                        print("")
                        print("Back(0): ")
                        print("")

            # --- --- --- --- --- --- --- --- --- ---
            # Code for Stock
            # --- --- --- --- --- --- --- --- --- ---   

            if mainMenuSelect == "4":
            # --- --- --- --- --- --- --- --- --- --- 
                        #Stock Functions
            # Functions for stock related functionality.
            # --- --- --- --- --- --- --- --- --- --- 
                def areYouSure():
                    areYouSure = input("Are you sure you to continue? (y/n): ")
                    if areYouSure == "y" or areYouSure == "yes":
                        pass
                    else:
                        CtuStock.mainMenu(self)
            # --- --- --- --- --- --- --- --- --- --- 
            # --- --- --- --- --- --- --- --- --- --- 
                while True:
                    print("")
                    print("=== Stock ===")
                    print("1. Display stock")
                    print("2. Add stock")
                    print("0. Back")
                    choice = input("Enter your choice:")
                    if choice == "1":
                        print("")
                        print("Stock information: ")
                        print(f"Hardrives: {self.hardrives} ")
                        print("")
                    if choice == "2":
                        howMuch = int(input("How much stock do you want to add?"))
                        areYouSure()
                        self.hardrives += howMuch
                        print(f"Updated Stock: {self.hardrives} ")
                    if choice == "0":
                        CtuStock.mainMenu(self)
            if mainMenuSelect == "99":
                print("Exiting application.")
        break

# === === === === === === ===

shops = CtuStock()

shops.mainMenu()


"""
  #Shopname Attributes for 4 shops
            self = "default", 
            shopName = "default", 
            #Shoplocation Attributes for 4 shops
            shopLocation = "default", 
            #Customers Attributes for 4 shops
            customers = 0, 
            #Sales Attributes for 4 shops
            sales = 0, 
            #Return Attributes for 4 shops
            returns = 0,
            hardrives = 1000,
            updatedHardStock = 0,
            counter = "off/on",
            counter1 = "off/on",
            
            itemNumber = 0,
            quanToSell = 0,
            ):

        self.shopName = shopName
        self.shopLocation = shopLocation
        self.customers = customers
        self.sales = sales
        self.returns = returns
        self.hardrives = hardrives
        self.updatedHardStock = updatedHardStock
        self.counter = counter
        self.counter1 = counter1
        self.itemNumber = itemNumber
        self.quanToSell = quanToSell
"""