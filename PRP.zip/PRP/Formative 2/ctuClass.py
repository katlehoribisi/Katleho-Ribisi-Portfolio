class CtuStock:
    def __init__(
            #Shopname Attributes for 4 shops
            self, 
            shopName, 
            shopName1, 
            shopName2, 
            shopName3,

            #Shoplocation Attributes for 4 shops
            shopLocation, 
            shopLocation1, 
            shopLocation2, 
            shopLocation3, 

            #Customers Attributes for 4 shops
            customers, 
            customers1, 
            customers2, 
            customers3, 

            #Sales Attributes for 4 shops
            sales, 
            sales1, 
            sales2, 
            sales3, 

            #Return Attributes for 4 shops
            returns,
            returns1,
            returns2,
            returns3,
            hardrives,
            updatedHardStock,
            counter,
            counter1,
            
            itemNumber,
            itemNumber1,
            itemNumber2,
            itemNumber3,

            quanToSell,
            quanToSell1,
            quanToSell2,
            quanToSell3,

            ):

        self.shopName = shopName
        self.shopName1 = shopName1
        self.shopName2 = shopName2
        self.shopName3 = shopName3

        self.shopLocation = shopLocation
        self.shopLocation1 = shopLocation1
        self.shopLocation2 = shopLocation2
        self.shopLocation3 = shopLocation3
        
        self.customers = customers
        self.customers1 = customers1
        self.customers2 = customers2
        self.customers3 = customers3
        
        self.sales = sales
        self.sales1 = sales1
        self.sales2 = sales2
        self.sales3 = sales3

        self.returns = returns
        self.returns1 = returns1
        self.returns2 = returns2
        self.returns3 = returns3
        self.hardrives = hardrives
        self.updatedHardStock = updatedHardStock
        self.counter = counter
        self.counter1 = counter1

        self.itemNumber = itemNumber
        self.itemNumber1 = itemNumber1
        self.itemNumber2 = itemNumber2
        self.itemNumber3 = itemNumber3
        
        self.quanToSell = quanToSell
        self.quanToSell1 = quanToSell1
        self.quanToSell2 = quanToSell2
        self.quanToSell3 = quanToSell3