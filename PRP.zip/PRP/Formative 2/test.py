from test2 import CTUStock
class CTUStock:
    def _init_(self, shopName="Default", shopLocation="Default", customers=0, sales=0, returns=0):
        self.shopName = shopName
        self.shopLocation = shopLocation
        self.customers = customers
        self.sales = sales
        self.returns = returns


    # Create four shop objects
    shop1 = CTUStock()
    shop2 = CTUStock()
    shop3 = CTUStock()
    shop4 = CTUStock()

    def display_main_menu():
        print("Main Menu:")
        print("1. Shop Management")
        print("2. Sales")
        print("3. Returns")
        print("4. Stock")
        print("99. Exit")

    def display_shop_management_menu():
        print("Shop Management Menu:")
        print("1. Change Shop Name")
        print("2. Change Shop Location")
        print("3. Display Current Shops")
        print("4. Display All Shop Information")
        print("0. Back")

    def change_shop_name():
        display_current_shops()
        choice = int(input("Select the shop number: "))
        if choice < 1 or choice > 4:
            print("Invalid shop number.")
            return
        shop = get_shop_by_choice(choice)
        new_name = input("Enter new shop name: ")
        if new_name.strip() == "":
            print("Shop name cannot be blank.")
        else:
            shop.shopName = new_name
            print("Shop name changed successfully.")

    def change_shop_location():
        display_current_shops()
        choice = int(input("Select the shop number: "))
        if choice < 1 or choice > 4:
            print("Invalid shop number.")
            return
        shop = get_shop_by_choice(choice)
        new_location = input("Enter new shop location: ")
        allowed_locations = ["Free State", "Gauteng", "KZN", "Limpopo", "Default"]
        if new_location not in allowed_locations:
            print("Invalid shop location.")
        else:
            shop.shopLocation = new_location
            print("Shop location changed successfully.")

    def display_current_shops():
        print("Current Shops:")
        for i, shop in enumerate([shop1, shop2, shop3, shop4], start=1):
            print(f"{i}. {shop.shopName} - {shop.shopLocation}")

    def display_all_shop_information():
        print("All Shop Information:")
        for i, shop in enumerate([shop1, shop2, shop3, shop4], start=1):
            print(f"Shop {i}:")
            print(f"Shop Name: {shop.shopName}")
            print(f"Shop Location: {shop.shopLocation}")
            print(f"Customers: {shop.customers}")
            print(f"Sales: {shop.sales}")
            print(f"Returns: {shop.returns}")
            print()

    def get_shop_by_choice(choice):
        if choice == 1:
            return shop1
        elif choice == 2:
            return shop2
        elif choice == 3:
            return shop3
        elif choice == 4:
            return shop4

    def shop_management():
        while True:
            display_shop_management_menu()
            choice = input("Enter your choice: ")
            if choice == "1":
                change_shop_name()
            elif choice == "2":
                change_shop_location()
            elif choice == "3":
                display_current_shops()
            elif choice == "4":
                display_all_shop_information()
            elif choice == "0":
                break
            else:
                print("Invalid choice.")

    def sales():
        # Implement sales menu functionality here
        pass

    def returns():
        # Implement returns menu functionality here
        pass

    def stock():
        # Implement stock menu functionality here
        pass

    def main():
        while True:
            display_main_menu()
            choice = input("Enter your choice: ")
            if choice == "1":
                shop_management()
            elif choice == "2":
                sales()
            elif choice == "3":
                returns()
            elif choice == "4":
                stock()
            elif choice == "99":
                print("Exiting the application.")
                break
            else:
                print("Invalid choice.")

    if __name__ == "_main_":
main()

