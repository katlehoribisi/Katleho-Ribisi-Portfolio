import time
from ctuClass import CtuStock
import sys

shops = CtuStock(
    "Default","Default","Default","Default",#Shopname
    "Default","Default","Default","Default",#ShopLocation
    
    0,0,0,0, #Customers
    0,0,0,0, #Sales
    0,0,0,0, #Returns

    1000, #Hardrives
    0, #Updated Hardstock
    "On/Off", #Counter
    "On/Off", #Counter
    
    0, #Item Number
    0, #Item Number
    0, #Item Number
    0, #Item Number

    0, #Quantity to sell
    0, #Quantity to sell1
    0, #Quantity to sell2
    0, #Quantity to sell3
    )


#Code for the main menu
while True:
    def mainMenu(shops):
        shops.updatedHardStock = shops.hardrives - shops.quanToSell - shops.quanToSell1 - shops.quanToSell2 - shops.quanToSell3
        print("Welcome to CTU Technologies")
        print("")
        print("1. Shop Management")
        print("2. Sales")
        print("3. Returns")
        print("4. Stock")
        print("99. Exit")
        print("")
        
        mainMenuSelect = input("Select an option or 99 to exit: ")
        newRange = (1,4)
        if mainMenuSelect == "1" or mainMenuSelect == "2" or mainMenuSelect == "3" or mainMenuSelect == "4" or mainMenuSelect == "99":
            pass
        else:
            print("Please enter a correct number!")
            mainMenu(shops)

                
        if mainMenuSelect == "1":
            print("")
            
            print("Shop Management")
            print("1. Change shop Name")
            print("2. Change shop location")
            print("3. Display current shops")
            print("4. Display all shops information")
            print("0. Back")
            print("")

            nestSelect = input("Select an option: ")
            if nestSelect == "0":
                mainMenu(shops)

        # --- --- --- --- --- --- --- --- --- --- 
                        #Option 1 
            # Functions to change the shopnames
            # Functions to change shoplocations
            # Functions to design a buy function
        # --- --- --- --- --- --- --- --- --- --- 
            def change():
                shops.shopName = input("Type the new Shop name: ")

                areYouSure = input("Are you sure you want to confirm this answer?: (y/n)")
                if areYouSure == "y" or areYouSure == "yes":
                    print(f"Shop name was succsessfully changed to: {shops.shopName}")
                else:
                    shops.shopName = "Default"

            def change1():
                shops.shopName1 = input("Type the new Shop name: ")

                areYouSure = input("Are you sure you want to confirm this answer? (y/n): ")
                if areYouSure == "y" or areYouSure == "yes":
                    print(f"Shop name was succsessfully changed to: {shops.shopName1}")
                else:
                    shops.shopName1 = "Default"

            def change2():
                shops.shopName2 = input("Type the new Shop name: ")

                areYouSure = input("Are you sure you want to confirm this answer? (y/n): ")
                if areYouSure == "y" or areYouSure == "yes":
                    print(f"Shop name was succsessfully changed to: {shops.shopName2}")
                else:
                    shops.shopName2 = "Default"

            def change3():
                shops.shopName3 = input("Type the new Shop name: ")

                areYouSure = input("Are you sure you want to confirm this answer? (y/n): ")
                if areYouSure == "y" or areYouSure == "yes":
                    print(f"Shop name was succsessfully changed to: {shops.shopName3}")
                else:
                    shops.shopName3 = "Default"

            #Functions to change the shop locations
            def changeLocation():
                shops.shopLocation = input("Enter a location Free State, Gauteng, KZN, Limpopo: ")
                areYouSure = input("Are you sure you want to confirm this answer? (y/n): ")
                if areYouSure == "y" or areYouSure == "yes":
                    #--- --- ---
                    #List required in code.
                    #--- --- ---
                    listOfLocation = ["Free State","Gauteng","KZN","Limpopo"]
                    for i in listOfLocation:
                        if shops.shopLocation in listOfLocation:
                            print(f"Shop location successfully changed to: {shops.shopLocation}")
                            break
                        else:
                            print("--- ----")
                            print("Shop name invalid.")
                            print("--- ----")
                            shops.shopLocation = "Default"
                            break
                else:
                    pass

            def changeLocation1():
                shops.shopLocation1 = input("Enter a location Free State, Gauteng, KZN, Limpopo: ")
                areYouSure = input("Are you sure you want to confirm this answer? (y/n): ")
                if areYouSure == "y" or areYouSure == "yes":
                    #--- --- ---
                    #List required in code.
                    #--- --- ---
                    listOfLocation = ["Free State","Gauteng","KZN","Limpopo"]
                    for i in listOfLocation:
                        if shops.shopLocation1 in listOfLocation:
                            print(f"Shop location successfully changed to: {shops.shopLocation1}")
                            break
                        else:
                            print("--- ----")
                            print("Shop name invalid.")
                            print("--- ----")
                            shops.shopLocation1 = "Default"
                            break
                else:
                    pass

            def changeLocation2():
                shops.shopLocation2 = input("Enter a location Free State, Gauteng, KZN, Limpopo: ")
                areYouSure = input("Are you sure you want to confirm this answer? (y/n): ")
                if areYouSure == "y" or areYouSure == "yes":
                    #--- --- ---
                    #List required in code.
                    #--- --- ---
                    listOfLocation = ["Free State","Gauteng","KZN","Limpopo"]
                    for i in listOfLocation:
                        if shops.shopLocation2 in listOfLocation:
                            print(f"Shop location successfully changed to: {shops.shopLocation2}")
                            break
                        else:
                            print("--- ----")
                            print("Shop name invalid.")
                            print("--- ----")
                            shops.shopLocation2 = "Default"
                            break
                else:
                    pass

            def changeLocation3():
                shops.shopLocation3 = input("Enter a location Free State, Gauteng, KZN, Limpopo: ")

                areYouSure = input("Are you sure you want to confirm this answer? (y/n): ")
                if areYouSure == "y" or areYouSure == "yes":
                    #--- --- ---
                    #List required in code.
                    #--- --- ---
                    listOfLocation = ["Free State","Gauteng","KZN","Limpopo"]
                    for i in listOfLocation:
                        if shops.shopLocation3 in listOfLocation:
                            print(f"Shop location successfully changed to: {shops.shopLocation3}")
                            break
                        else:
                            print("--- ----")
                            print("Shop name invalid.")
                            print("--- ----")
                            shops.shopLocation3 = "Default"
                            break
                else:
                    pass
            #--- --- --- --- --- --- --- --- --- --- 
            #--- --- --- --- --- --- --- --- --- --- 


            while True:
                #Change shop name code
                if nestSelect == "1":
                    print("Change shop name")
                    print("")
                    print("Select Shop")
                    print("1.",shops.shopName)
                    print("2.",shops.shopName1)
                    print("3.",shops.shopName2)
                    print("4.",shops.shopName3)
                    print("0. Back")
                    nestSelect2 = input("Select an option: ")
                    if nestSelect2 == "1":
                        change()
                    elif nestSelect2 == "2":
                        change1()
                    elif nestSelect2 == "3":
                        change2()
                    elif nestSelect2 == "4":
                        change3()
                    elif nestSelect2 == "0":
                        mainMenu(shops)

                #Change shop location code
                if nestSelect == "2":
                    print("Change shop Location")
                    print("")
                    print("Select Location")
                    print(f"1. {shops.shopName} {shops.shopLocation}")
                    print(f"2. {shops.shopName1} {shops.shopLocation1}")
                    print(f"3. {shops.shopName2} {shops.shopLocation2}")
                    print(f"4. {shops.shopName3} {shops.shopLocation3}")
                    print("0. Back") 
                    nestSelect2 = input("Select an option: ")
                    if nestSelect2 == "1":
                        changeLocation()
                    elif nestSelect2 == "2":
                        changeLocation1()
                    elif nestSelect2 == "3":
                        changeLocation2()
                    elif nestSelect2 == "4":
                        changeLocation3()
                    elif nestSelect2 == "0":
                        print("Works")
                        mainMenu(shops)

                if nestSelect == "3":
                    def showShops():
                        print("Current Shops")
                        print("")                
                        print(f"Shop 1 is: {shops.shopName}, {shops.shopLocation}")
                        print(f"Shop 2 is: {shops.shopName1}, {shops.shopLocation1}")
                        print(f"Shop 3 is: {shops.shopName2}, {shops.shopLocation2}")
                        print(f"Shop 4 is: {shops.shopName3}, {shops.shopLocation3}")
                        print("")  
                    showShops() 
                    mainMenu(shops)
                if nestSelect == "4":
                    def showAll():
                        #Shop 1
                        print("----------------")
                        print("#Shop 1#")
                        print("----------------")
                        print("")
                        print(f"Shop Name: {shops.shopName}")
                        print(f"Shop Location: {shops.shopLocation}")
                        print(f"Number of Customers: {shops.customers}")
                        print(f"Current Sales: {shops.sales}")
                        print("")
                        print("----------------")
                        print("")

                        #Shop 2
                        print("----------------")
                        print("#Shop 2#")
                        print("----------------")
                        print("")
                        print(f"Shop Name: {shops.shopName1}")
                        print(f"Shop Location: {shops.shopLocation1}")
                        print(f"Number of Customers: {shops.customers1}")
                        print(f"Current Sales: {shops.sales1}")
                        print("")
                        print("----------------")
                        print("")

                        #Shop 3
                        print("----------------")
                        print("#Shop 3#")
                        print("----------------")
                        print("")
                        print(f"Shop Name: {shops.shopName2}")
                        print(f"Shop Location: {shops.shopLocation2}")
                        print(f"Number of Customers: {shops.customers2}")
                        print(f"Current Sales: {shops.sales2}")
                        print("")
                        print("----------------")
                        print("")

                        #Shop 4
                        print("----------------")
                        print("#Shop 4#")
                        print("----------------")
                        print("")
                        print(f"Shop Name: {shops.shopName3}")
                        print(f"Shop Location: {shops.shopLocation3}")
                        print(f"Number of Customers: {shops.customers3}")
                        print(f"Current Sales: {shops.sales3}")
                        print("")
                        print("----------------")
                        print("")
                    showAll()
                
                    mainMenu(shops)
                    
        # --- --- --- --- --- --- --- --- --- ---
        # Code for SALES 
        # --- --- --- --- --- --- --- --- --- --- 
        if mainMenuSelect == "2":

            # --- --- --- --- --- --- --- --- --- --- 
                            #Option 2 (Sales)
            # Functions to repeat code without the input
            # --- --- --- --- --- --- --- --- --- --- 
            def showSalesSoFar():
                print("")
                print("Current Sales Information: ")
                print("=== === === ")
                print(f"Hardrives stock: {shops.updatedHardStock}") 
                print(f"Quantity sold for Shop 1: {shops.quanToSell}")
                print(f"Quantity sold for Shop 2: {shops.quanToSell1}")
                print(f"Quantity sold for Shop 3: {shops.quanToSell2}")
                print(f"Quantity sold for Shop 4: {shops.quanToSell3}")
                print("=== === === ")
            
            def availableItems():
                prev = input("Do you want to sell again?: ")
                if prev == "y":
                    shops.counter = "off"
                    pass
                elif prev == "n":
                    showSalesSoFar()
                    mainMenu(shops)

            def itemNumber():
                itemSell = int(input(f"2. Enter the item number to sell: "))
                if itemSell == 0:
                    shops.counter = "off"
                    mainMenu(shops)
                else:
                    shops.itemNumber = itemSell
            def itemNumber1():
                itemSell = int(input(f"2. Enter the item number to sell: "))
                if itemSell == 0:
                    shops.counter = "off"
                    mainMenu(shops)
                else:
                    shops.itemNumber1 = itemSell
            def itemNumber2():
                itemSell = int(input(f"2. Enter the item number to sell: "))
                if itemSell == 0:
                    shops.counter = "off"
                    mainMenu(shops)
                else:
                    shops.itemNumber2 = itemSell
            def itemNumber3():
                itemSell = int(input(f"2. Enter the item number to sell: "))
                if itemSell == 0:
                    shops.counter = "off"
                    mainMenu(shops)
                else:
                    shops.itemNumber3 = itemSell

            def quanToSell():
                quanToSell = int(input(f"3. Enter the quantity to sell: "))
                shops.quanToSell += quanToSell
                shops.customers += 1

            def quanToSell1():
                quanToSell = int(input(f"3. Enter the quantity to sell: "))
                shops.quanToSell1 += quanToSell
                shops.customers1 += 1

            def quanToSell2():
                quanToSell = int(input(f"3. Enter the quantity to sell: "))
                shops.quanToSell2 += quanToSell
                shops.customers2 += 1

            def quanToSell3():
                quanToSell = int(input(f"3. Enter the quantity to sell: "))
                shops.quanToSell3 += quanToSell
                shops.customers3 += 1
                
                if quanToSell > 1000:
                    print("==============================")
                    print("Not enough in stock, sorry :(")
                    print("==============================")
                    shops.counter = "off"
                    mainMenu(shops)

            def back():
                print(f"Item {shops.itemNumber} sold successfully!")
                print("")
                back = input("Do you want to go back to main menu? (y/n): ")
                if back == "y" or back == "Y" or back == "Yes" or back == "yes":
                    mainMenu(shops)
                elif back == "n" or back == "no":
                    showSales()
                    

            # --- --- --- --- --- --- --- --- --- ---
            # Sales code.
            # --- --- --- --- --- --- --- --- --- ---
            while True:
                if shops.counter == "on":
                    availableItems()
                else:
                    def showSales():
                        shops.counter = "on"
                        print("=== Sales ===")
                        print("Available items: ")
                        print("back: (0) ")
                        print(f"1. Hardrives: {shops.updatedHardStock}")

                        while True:
                            sellFrom = int(input(f"4. Enter the shop number to sell from: "))
                            myRange = range(1,5)

                            if sellFrom == 1:
                                itemNumber()
                                quanToSell()
                                shops.sales = shops.quanToSell #Shop 1
                                back()

                            if sellFrom == 2:
                                itemNumber1()
                                quanToSell1()
                                shops.sales1 = shops.quanToSell1 #Shop 2
                                back()
                            
                            if sellFrom == 3:
                                itemNumber2()
                                quanToSell2()
                                shops.sales2 = shops.quanToSell2 #Shop 3
                                back()

                            if sellFrom == 4:
                                itemNumber3()
                                quanToSell3()
                                shops.sales3 = shops.quanToSell3 #Shop 4
                                back()
                            
                            if sellFrom in myRange:
                                pass
                            else:
                                print("Shop doesn't exist")

                    showSales()

        # --- --- --- --- --- --- --- --- --- ---
        # Code for RETURNS
        # --- --- --- --- --- --- --- --- --- --- 
        if mainMenuSelect == "3":
            while True:
                # --- --- --- --- --- --- --- --- --- --- 
                                #Option 3
                # Functions to Return an item back to the shop
                # --- --- --- --- --- --- --- --- --- ---

                
                def showReturnsInformation():
                    print("")
                    print("Current Returns Information: ")
                    print("=== === === ")
                    print(f"Hardrives stock: {shops.updatedHardStock}") 
                    print(f"Quantity returned for Shop 1: {shops.quanToSell},        Item Number: {shops.itemNumber}")
                    print(f"Quantity returned for Shop 2: {shops.quanToSell1},       Item Number: {shops.itemNumber1}")
                    print(f"Quantity returned for Shop 3: {shops.quanToSell2},       Item Number: {shops.itemNumber2}")
                    print(f"Quantity returned for Shop 4: {shops.quanToSell3},       Item Number: {shops.itemNumber3}")
                    print("=== === === ")

                def shopToReturn():
                    return1 = int(input(f"How much do you want to return?: "))
                    if return1 > shops.sales:
                        print("")
                        print("Couldn't return, sorry.")
                        print("")
                        mainMenu(shops)
                    else:
                        shops.sales -= return1
                        shops.hardrives += return1
                def shopToReturn1():
                    return2 = int(input(f"How much do you want to return?: "))
                    if return2 > shops.sales1:
                        print("")
                        print("Couldn't return, sorry.")
                        print("")
                        mainMenu(shops)
                    else:
                        shops.sales1 -= return2
                        shops.hardrives += return2
                def shopToReturn2():
                    return3 = int(input(f"How much do you want to return?: "))
                    if return3 > shops.sales2:
                        print("")
                        print("Couldn't return, sorry.")
                        print("")
                        mainMenu(shops)
                    else:
                        shops.sales2 -= return3
                        shops.hardrives += return3
                def shopToReturn3():
                    return4 = int(input(f"How much do you want to return?: "))
                    if return4 > shops.sales3:
                        print("")
                        print("Couldn't return, sorry.")
                        print("")
                        mainMenu(shops)
                    else:
                        shops.sales3 -= return4
                        shops.hardrives += return4


                # --- --- --- --- --- --- --- --- --- ---

                print("")
                print("=== Returns === ")
                print("Available Items: ")
                print(f"1. Hardrives: {shops.updatedHardStock}")
                while True:
                    returnTo = int(input(f"Enter the shop number to return to: "))
                    
                    myRange = range(1,5)
                    if returnTo == 1:
                        shopToReturn()
                    if returnTo == 2:
                        shopToReturn1()
                    if returnTo == 3:
                        shopToReturn2()
                    if returnTo == 4:
                        shopToReturn3()

                    if returnTo in myRange:
                        back = input("Are you sure with these values? (y/n): ")
                        print(f"Item {shops.itemNumber} returned successfully!")
                        print("")
                        if back == "y" or back == "Y" or back == "Yes" or back == "yes":
                            mainMenu(shops)
                        elif back == "n" or back == "no":
                            showReturnsInformation()
                    else:
                        print("Shop doesn't exist.")

                    print(f"Enter the quantity to return: {shops.returns2}")
                    print(f"Enter the shop number to return to: {shops.returns3}")
                    print("")
                    print("Back(0): ")
                    print("")

        # --- --- --- --- --- --- --- --- --- ---
        # Code for Stock
        # --- --- --- --- --- --- --- --- --- ---   

        if mainMenuSelect == "4":
        # --- --- --- --- --- --- --- --- --- --- 
                    #Stock Functions
        # Functions for stock related functionality.
        # --- --- --- --- --- --- --- --- --- --- 
            def areYouSure():
                areYouSure = input("Are you sure you to continue? (y/n): ")
                if areYouSure == "y" or areYouSure == "yes":
                    pass
                else:
                    mainMenu(shops)
        # --- --- --- --- --- --- --- --- --- --- 
        # --- --- --- --- --- --- --- --- --- --- 
            while True:
                print("")
                print("=== Stock ===")
                print("1. Display stock")
                print("2. Add stock")
                print("0. Back")
                choice = input("Enter your choice:")
                if choice == "1":
                    print("")
                    print("Stock information: ")
                    print(f"Hardrives: {shops.hardrives - shops.quanToSell - shops.quanToSell1 - shops.quanToSell2 - shops.quanToSell3} ")
                    print("")
                if choice == "2":
                    howMuch = int(input("How much stock do you want to add?"))
                    areYouSure()
                    shops.hardrives += howMuch
                    print(f"Updated Stock: {shops.hardrives} ")
                if choice == "0":
                    mainMenu(shops)
        if mainMenuSelect == "99":
            print("Exiting application.")
            time.sleep(0.5)
            (print("Exiting application.."))
            time.sleep(0.5)
            print("Exiting application...")
            time.sleep(0.5)
            sys.exit()
    break

mainMenu(shops)