class CTUStock:
    def __init__(self, shopName="Default", shopLocation="Default", customers=0, sales=0, returns=0):
        self.shopName = shopName
        self.shopLocation = shopLocation
        self.customers = customers
        self.sales = sales
        self.returns = returns
